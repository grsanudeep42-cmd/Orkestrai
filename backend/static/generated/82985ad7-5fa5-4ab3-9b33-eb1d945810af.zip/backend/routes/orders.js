const express = require('express');
const orderController = require('../controllers/orderController');
const { isAuthenticated } = require('../utils/auth');

const router = express.Router();

router.get('/', isAuthenticated, orderController.getAllOrders);
router.get('/:id', isAuthenticated, orderController.getOrder);
router.post('/', isAuthenticated, orderController.createOrder);
router.put('/:id', isAuthenticated, orderController.updateOrder);
router.delete('/:id', isAuthenticated, orderController.cancelOrder);

module.exports = router;
