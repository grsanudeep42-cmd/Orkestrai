const express = require('express');
const userController = require('../controllers/userController');
const { isAuthenticated } = require('../utils/auth');

const router = express.Router();

router.post('/register', userController.registerUser);
router.post('/login', userController.loginUser);
router.get('/me', isAuthenticated, userController.getCurrentUser);
router.put('/me', isAuthenticated, userController.updateUser);

module.exports = router;
