const express = require('express');
const productController = require('../controllers/productController');
const { isAuthenticated, isSeller } = require('../utils/auth');

const router = express.Router();

router.get('/', productController.getAllProducts);
router.get('/:id', productController.getProduct);
router.post('/', isAuthenticated, isSeller, productController.createProduct);
router.put('/:id', isAuthenticated, isSeller, productController.updateProduct);
router.delete('/:id', isAuthenticated, isSeller, productController.deleteProduct);

module.exports = router;
