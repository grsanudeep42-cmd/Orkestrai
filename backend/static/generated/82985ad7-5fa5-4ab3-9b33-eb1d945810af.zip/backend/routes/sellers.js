const express = require('express');
const sellerController = require('../controllers/sellerController');
const { isAuthenticated, isSeller } = require('../utils/auth');

const router = express.Router();

router.post('/register', sellerController.registerSeller);
router.post('/login', sellerController.loginSeller);
router.get('/me', isAuthenticated, isSeller, sellerController.getCurrentSeller);
router.put('/me', isAuthenticated, isSeller, sellerController.updateSeller);

module.exports = router;
