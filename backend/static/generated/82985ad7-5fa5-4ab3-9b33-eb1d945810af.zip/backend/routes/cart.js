const express = require('express');
const cartController = require('../controllers/cartController');
const { isAuthenticated } = require('../utils/auth');

const router = express.Router();

router.get('/', isAuthenticated, cartController.getCart);
router.post('/', isAuthenticated, cartController.addToCart);
router.put('/:id', isAuthenticated, cartController.updateCartItem);
router.delete('/:id', isAuthenticated, cartController.removeFromCart);

module.exports = router;
