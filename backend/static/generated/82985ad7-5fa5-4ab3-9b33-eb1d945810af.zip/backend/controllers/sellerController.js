const Seller = require('../models/Seller');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

exports.registerSeller = async (req, res) => {
  try {
    const { name, email, password, companyName, description } = req.body;
    const existingSeller = await Seller.findOne({ where: { email } });
    if (existingSeller) {
      return res.status(400).json({ message: 'Email already registered' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const seller = await Seller.create({
      name,
      email,
      password: hashedPassword,
      companyName,
      description,
    });
    const token = jwt.sign({ id: seller.id }, process.env.JWT_SECRET, { expiresIn: '1d' });
    res.status(201).json({ seller, token });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.loginSeller = async (req, res) => {
  try {
    const { email, password } = req.body;
    const seller = await Seller.findOne({ where: { email } });
    if (!seller) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    const isPasswordValid = await bcrypt.compare(password, seller.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    const token = jwt.sign({ id: seller.id }, process.env.JWT_SECRET, { expiresIn: '1d' });
    res.status(200).json({ seller, token });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getCurrentSeller = async (req, res) => {
  try {
    const seller = await Seller.findByPk(req.seller.id);
    res.status(200).json(seller);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateSeller = async (req, res) => {
  try {
    const seller = await Seller.findByPk(req.seller.id);
    await seller.update(req.body);
    res.status(200).json(seller);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
