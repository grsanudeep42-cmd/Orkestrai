const express = require('express');
const router = express.Router();
const projectController = require('../controllers/projects');

router.post('/', projectController.createProject);
router.get('/', projectController.getProjects);
router.get('/:id', projectController.getProjectById);
router.put('/:id', projectController.updateProject);
router.delete('/:id', projectController.deleteProject);

router.post('/collaborators', projectController.addCollaborator);
router.get('/:id/collaborators', projectController.getCollaborators);

module.exports = router;
