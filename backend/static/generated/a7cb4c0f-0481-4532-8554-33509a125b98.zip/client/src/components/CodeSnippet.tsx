import React from 'react';

interface CodeSnippetProps {
  title: string;
  code: string;
  userId: number;
}

const CodeSnippet: React.FC<CodeSnippetProps> = ({ title, code, userId }) => {
  return (
    <div>
      <h3>{title}</h3>
      <pre>
        <code>{code}</code>
      </pre>
      <p>User ID: {userId}</p>
    </div>
  );
};

export default CodeSnippet;
