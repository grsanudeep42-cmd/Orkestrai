import React from 'react';

interface ProjectProps {
  title: string;
  description: string;
  userId: number;
}

const Project: React.FC<ProjectProps> = ({ title, description, userId }) => {
  return (
    <div>
      <h3>{title}</h3>
      <p>{description}</p>
      <p>User ID: {userId}</p>
    </div>
  );
};

export default Project;
