import React, { useState, useEffect } from 'react';
import axios from 'axios';
import CodeSnippet from '../components/CodeSnippet';

const CodeSnippetPage: React.FC = () => {
  const [codeSnippets, setCodeSnippets] = useState<
    { id: number; title: string; code: string; userId: number }[]
  >([]);

  useEffect(() => {
    const fetchCodeSnippets = async () => {
      const response = await axios.get('/api/code-snippets');
      setCodeSnippets(response.data);
    };
    fetchCodeSnippets();
  }, []);

  return (
    <div>
      <h1>Code Snippets</h1>
      {codeSnippets.map((snippet) => (
        <CodeSnippet
          key={snippet.id}
          title={snippet.title}
          code={snippet.code}
          userId={snippet.userId}
        />
      ))}
    </div>
  );
};

export default CodeSnippetPage;
