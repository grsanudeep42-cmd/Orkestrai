import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Project from '../components/Project';

const ProjectPage: React.FC = () => {
  const [projects, setProjects] = useState<
    { id: number; title: string; description: string; userId: number }[]
  >([]);

  useEffect(() => {
    const fetchProjects = async () => {
      const response = await axios.get('/api/projects');
      setProjects(response.data);
    };
    fetchProjects();
  }, []);

  return (
    <div>
      <h1>Projects</h1>
      {projects.map((project) => (
        <Project
          key={project.id}
          title={project.title}
          description={project.description}
          userId={project.userId}
        />
      ))}
    </div>
  );
};

export default ProjectPage;
