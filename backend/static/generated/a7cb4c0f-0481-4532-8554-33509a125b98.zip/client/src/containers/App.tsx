import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import CodeSnippetPage from './CodeSnippetPage';
import ProjectPage from './ProjectPage';

const App: React.FC = () => {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/code-snippets">
            <CodeSnippetPage />
          </Route>
          <Route path="/projects">
            <ProjectPage />
          </Route>
        </Switch>
      </div>
    </Router>
  );
};

export default App;
