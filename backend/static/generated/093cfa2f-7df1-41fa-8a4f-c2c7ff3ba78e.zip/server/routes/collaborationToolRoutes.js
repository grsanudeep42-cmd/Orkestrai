const express = require('express');
const router = express.Router();
const collaborationToolController = require('../controllers/collaborationToolController');

// Create a new collaboration tool
router.post('/', collaborationToolController.createCollaborationTool);

// Get all collaboration tools
router.get('/', collaborationToolController.getAllCollaborationTools);

// Get a collaboration tool by ID
router.get('/:id', collaborationToolController.getCollaborationToolById);

// Update a collaboration tool
router.put('/:id', collaborationToolController.updateCollaborationTool);

// Delete a collaboration tool
router.delete('/:id', collaborationToolController.deleteCollaborationTool);

module.exports = router;
