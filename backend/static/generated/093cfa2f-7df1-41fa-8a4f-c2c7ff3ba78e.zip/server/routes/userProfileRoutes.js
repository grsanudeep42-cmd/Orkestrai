const express = require('express');
const router = express.Router();
const userProfileController = require('../controllers/userProfileController');

// Create a new user profile
router.post('/', userProfileController.createUserProfile);

// Get all user profiles
router.get('/', userProfileController.getAllUserProfiles);

// Get a user profile by ID
router.get('/:id', userProfileController.getUserProfileById);

// Update a user profile
router.put('/:id', userProfileController.updateUserProfile);

// Delete a user profile
router.delete('/:id', userProfileController.deleteUserProfile);

module.exports = router;
