const express = require('express');
const router = express.Router();
const codeSnippetController = require('../controllers/codeSnippetController');

// Create a new code snippet
router.post('/', codeSnippetController.createCodeSnippet);

// Get all code snippets
router.get('/', codeSnippetController.getAllCodeSnippets);

// Get a code snippet by ID
router.get('/:id', codeSnippetController.getCodeSnippetById);

// Update a code snippet
router.put('/:id', codeSnippetController.updateCodeSnippet);

// Delete a code snippet
router.delete('/:id', codeSnippetController.deleteCodeSnippet);

module.exports = router;
