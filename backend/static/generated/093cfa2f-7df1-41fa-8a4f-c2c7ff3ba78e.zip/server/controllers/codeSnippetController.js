const CodeSnippet = require('../models/CodeSnippet');

exports.createCodeSnippet = async (req, res) => {
  try {
    const { title, description, code, language, tags, userId } = req.body;
    const codeSnippet = new CodeSnippet({
      title,
      description,
      code,
      language,
      tags,
      userId,
    });
    await codeSnippet.save();
    res.status(201).json(codeSnippet);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.getAllCodeSnippets = async (req, res) => {
  try {
    const codeSnippets = await CodeSnippet.find();
    res.json(codeSnippets);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getCodeSnippetById = async (req, res) => {
  try {
    const codeSnippet = await CodeSnippet.findById(req.params.id);
    if (!codeSnippet) {
      return res.status(404).json({ message: 'Code snippet not found' });
    }
    res.json(codeSnippet);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateCodeSnippet = async (req, res) => {
  try {
    const codeSnippet = await CodeSnippet.findByIdAndUpdate(req.params.id, req