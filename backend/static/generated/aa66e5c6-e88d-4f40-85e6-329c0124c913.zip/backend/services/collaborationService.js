const Snippet = require('../models/Snippet');

let collaborationSessions = {};

exports.getCollaborationSession = async (snippetId) => {
  if (collaborationSessions[snippetId]) {
    return collaborationSessions[snippetId];
  }

  const snippet = await Snippet.findById(snippetId);
  if (!snippet) {
    throw new Error('Snippet not found');
  }

  collaborationSessions[snippetId] = {
    snippetId,
    users: [],
    code: snippet.code,
  };

  return collaborationSessions[snippetId];
};

exports.joinCollaborationSession = async (snippetId, userId) => {
  const collaborationSession = await this.getCollaborationSession(snippetId);
  collaborationSession.users.push(userId);
  return collaborationSession;
};

exports.updateCollaborationSession = async (snippetId, updates) => {
  const collaborationSession = await this.getCollaborationSession(snippetId);
  collaborationSession.code = updates.code;
  return collaborationSession;
};

exports.leaveCollaborationSession = async (snippetId, userId) => {
  const collaborationSession = await this.getCollaborationSession(snippetId);
  collaborationSession.users = collaborationSession.users.filter((user) => user !== userId);
  return collaborationSession;
};
