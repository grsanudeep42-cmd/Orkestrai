const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const snippetRoutes = require('./routes/snippetRoutes');
const collaborationRoutes = require('./routes/collaborationRoutes');
const authRoutes = require('./routes/authRoutes');
const { initializeSocketIO } = require('./utils/socket');

dotenv.config();

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('Connected to MongoDB'))
.catch((err) => console.error('Error connecting to MongoDB:', err));

// Routes
app.use('/api/snippets', snippetRoutes);
app.use('/api/collaboration', collaborationRoutes);
app.use('/api/auth', authRoutes);

// Initialize Socket.IO
const server = app.listen(process.env.PORT, () => {
  console.log(`Server is running on port ${process.env.PORT}`);
  initializeSocketIO(server);
});
