const express = require('express');
const collaborationController = require('../controllers/collaborationController');

const router = express.Router();

router.get('/:snippetId', collaborationController.getCollaborationSession);
router.post('/:snippetId', collaborationController.joinCollaborationSession);
router.put('/:snippetId', collaborationController.updateCollaborationSession);
router.delete('/:snippetId', collaborationController.leaveCollaborationSession);

module.exports = router;
