const express = require('express');
const snippetController = require('../controllers/snippetController');

const router = express.Router();

router.get('/', snippetController.getAllSnippets);
router.get('/:id', snippetController.getSnippetById);
router.post('/', snippetController.createSnippet);
router.put('/:id', snippetController.updateSnippet);
router.delete('/:id', snippetController.deleteSnippet);

module.exports = router;
