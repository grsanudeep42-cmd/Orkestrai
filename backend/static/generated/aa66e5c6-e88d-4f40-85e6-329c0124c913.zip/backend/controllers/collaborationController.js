const Snippet = require('../models/Snippet');
const { getCollaborationSession, joinCollaborationSession, updateCollaborationSession, leaveCollaborationSession } = require('../services/collaborationService');

exports.getCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    const collaborationSession = await getCollaborationSession(req.params.snippetId);
    res.json(collaborationSession);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.joinCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    const collaborationSession = await joinCollaborationSession(req.params.snippetId, req.body.userId);
    res.json(collaborationSession);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    const collaborationSession = await updateCollaborationSession(req.params.snippetId, req.body);
    res.json(collaborationSession);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.leaveCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    await leaveCollaborationSession(req.params.snippetId, req.body.userId);
    res.json({ message: 'Left collaboration session' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
