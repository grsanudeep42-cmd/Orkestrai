const Snippet = require('../models/Snippet');
const User = require('../models/User');
const { searchSnippets } = require('../utils/elasticsearch');

exports.getAllSnippets = async (req, res) => {
  try {
    const snippets = await Snippet.find().populate('userId', 'username');
    res.json(snippets);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getSnippetById = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.id).populate('userId', 'username');
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }
    res.json(snippet);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createSnippet = async (req, res) => {
  const { title, description, code, tags, language, userId } = req.body;

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const snippet = new Snippet({
      title,
      description,
      code,
      tags,
      language,
      userId,
    });

    await snippet.save();
    user.snippets.push(snippet._id);
    await user.save();

    res.status(201).json(snippet);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.updateSnippet = async (req, res) => {
  const { title, description, code, tags, language } = req.body;

  try {
    const snippet = await Snippet.findById(req.params.id);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    snippet.title = title;
    snippet.description = description;
    snippet.code = code;
    snippet.tags = tags;
    snippet.language = language;

    await snippet.save();
    res.json(snippet);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.deleteSnippet = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.id);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    const user = await User.findById(snippet.userId);
    user.snippets.pull(snippet._id);
    await user.save();

    await snippet.remove();
    res.json({ message: 'Snippet deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
