const { Client } = require('@elastic/elasticsearch');

const client = new Client({
  node: process.env.ELASTICSEARCH_HOST,
});

exports.searchSnippets = async (query, language, tags) => {
  try {
    const response = await client.search({
      index: 'snippets',
      body: {
        query: {
          bool: {
            must: [
              { match: { title: query } },
              { match: { language: language } },
              { terms: { tags: tags } },
            ],
          },
        },
      },
    });

    return response.hits.hits.map((hit) => hit._source);
  } catch (error) {
    console.error('Error searching snippets:', error);
    throw error;
  }
};
