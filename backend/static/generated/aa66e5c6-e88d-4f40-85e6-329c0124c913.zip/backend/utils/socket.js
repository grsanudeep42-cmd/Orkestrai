const { Server } = require('socket.io');
const { getCollaborationSession, joinCollaborationSession, updateCollaborationSession, leaveCollaborationSession } = require('../services/collaborationService');

let io;

exports.initializeSocketIO = (server) => {
  io = new Server(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
    },
  });

  io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('join-collaboration', async (snippetId, userId) => {
      try {
        const collaborationSession = await joinCollaborationSession(snippetId, userId);
        socket.join(snippetId);
        io.to(snippetId).emit('collaboration-session-updated', collaborationSession);
      } catch (error) {
        console.error('Error joining collaboration session:', error);
      }
    });

    socket.on('update-collaboration', async (snippetId, updates) => {
      try {
        const collaborationSession = await updateCollaborationSession(snippetId, updates);
        io.to(snippetId).emit('collaboration-session-updated', collaborationSession);
      } catch (error) {
        console.error('Error updating collaboration session:', error);
      }
    });

    socket.on('leave-collaboration', async (snippetId, userId) => {
      try {
        await leaveCollaborationSession(snippetId, userId);
        socket.leave(snippetId);
        io.to(snippetId).emit('collaboration-session-updated', null);
      } catch (error) {
        console.error('Error leaving collaboration session:', error);
      }
    });

    socket.on('disconnect', () => {
      console.log('A user disconnected');
    });
  });
};
