import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import CodeSnippetCard from '../components/CodeSnippetCard';

const Home: React.FC = () => {
  const [featuredSnippets, setFeaturedSnippets] = useState<any[]>([]);

  useEffect(() => {
    const fetchFeature
