const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./utils/db');
const userRoutes = require('./routes/users');
const codeSnippetRoutes = require('./routes/codeSnippets');
const projectRoutes = require('./routes/projects');
const discussionRoutes = require('./routes/discussions');
const commentRoutes = require('./routes/comments');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

app.use('/api/users', userRoutes);
app.use('/api/code-snippets', codeSnippetRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/discussions', discussionRoutes);
app.use('/api/comments', commentRoutes);

db.sequelize.sync().then(() => {
  app.listen(3000, () => {
    console.log('Server is running on port 3000');
  });
});
