module.exports = (sequelize, DataTypes) => {
  const CodeSnippet = sequelize.define('CodeSnippet', {
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    code: {
      type: DataTypes.TEXT
