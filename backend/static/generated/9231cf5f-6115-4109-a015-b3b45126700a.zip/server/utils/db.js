const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    dialect: 'postgres',
  }
);

const db = {
  sequelize,
  User: require('../models/user')(sequelize),
  CodeSnippet: require('../models/codeSnippet')(sequelize),
  Project: require('../models/project')(sequelize),
  ProjectCollaborator: require('../models/projectCollaborator')(sequelize),
  Discussion: require('../models/discussion')(sequelize),
  Comment: require('../models/comment')(sequelize),
};

db.Project.belongsToMany(db.User, { through: db.ProjectCollaborator, as: 'collaborators' });
db.User.belongsToMany(db.Project, { through: db.ProjectCollaborator, as: 'projects' });
db.Discussion.hasMany(db.Comment, { as: 'comments' });
db.Comment.belongsTo(db.Discussion);

module.exports = db;
