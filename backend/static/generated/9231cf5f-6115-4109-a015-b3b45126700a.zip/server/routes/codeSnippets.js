const express = require('express');
const codeSnippetController = require('../controllers/codeSnippets');

const router = express.Router();

router.post('/', codeSnippetController.createCodeSnippet);
router.get('/', codeSnippetController.getAllCodeSnippets);
router.get('/:id', codeSnippetController.getCodeSnippetById);
router.put('/:id', codeSnippetController.updateCodeSnippet);
router.delete('/:id', codeSnippetController.deleteCodeSnippet);

module.exports = router;
