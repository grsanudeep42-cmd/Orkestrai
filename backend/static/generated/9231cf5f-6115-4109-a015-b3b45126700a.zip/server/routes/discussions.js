const express = require('express');
const discussionController = require('../controllers/discussions');

const router = express.Router();

router.post('/', discussionController.createDiscussion);
router.get('/', discussionController.getAllDiscussions);
router.get('/:id', discussionController.getDiscussionById);
router.put('/:id', discussionController.updateDiscussion);
router.delete('/:id', discussionController.deleteDiscussion);

module.exports = router;
