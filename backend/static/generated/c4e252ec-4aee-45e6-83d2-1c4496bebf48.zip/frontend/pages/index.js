import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ProductList from '../components/ProductList';
import SearchBar from '../components/SearchBar';

const HomePage = () => {
  const [products, setProducts]
