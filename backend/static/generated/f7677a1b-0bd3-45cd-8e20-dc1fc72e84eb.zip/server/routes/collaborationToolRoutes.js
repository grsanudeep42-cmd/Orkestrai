const express = require('express');
const router = express.Router();
const collaborationToolController = require('../controllers/collaborationToolController');

router.post('/', collaborationToolController.createCollaborationTool);
router.get('/', collaborationToolController.getAllCollaborationTools);
router.get('/:id', collaborationToolController.getCollaborationToolById);
router.put('/:id', collaborationToolController.updateCollaborationTool);
router.delete('/:id', collaborationToolController.deleteCollaborationTool);

module.exports = router;
