const express = require('express');
const router = express.Router();
const codeSnippetController = require('../controllers/codeSnippetController');

router.post('/', codeSnippetController.createCodeSnippet);
router.get('/', codeSnippetController.getAllCodeSnippets);
router.get('/:id', codeSnippetController.getCodeSnippetById);
router.put('/:id', codeSnippetController.updateCodeSnippet);
router.delete('/:id', codeSnippetController.deleteCodeSnippet);

module.exports = router;
