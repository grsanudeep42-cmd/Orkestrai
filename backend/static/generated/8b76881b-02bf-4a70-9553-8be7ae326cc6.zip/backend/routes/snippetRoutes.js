const express = require('express');
const router = express.Router();
const snippetController = require('../controllers/snippetController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/', snippetController.getAllSnippets);
router.get('/:id', snippetController.getSnippetById);
router.post('/', authMiddleware, snippetController.createSnippet);
router.put('/:id', authMiddleware, snippetController.updateSnippet);
router.delete('/:id', authMiddleware, snippetController.deleteSnippet);
router.get('/search', snippetController.searchSnippets);

module.exports = router;
