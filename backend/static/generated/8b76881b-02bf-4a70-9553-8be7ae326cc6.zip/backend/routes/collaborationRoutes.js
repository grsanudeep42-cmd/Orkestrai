const express = require('express');
const router = express.Router();
const collaborationController = require('../controllers/collaborationController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/:snippetId', collaborationController.getCollaborationSession);
router.post('/:snippetId', authMiddleware, collaborationController.joinCollaborationSession);
router.put('/:snippetId', authMiddleware, collaborationController.updateCollaborationSession);
router.delete('/:snippetId', authMiddleware, collaborationController.leaveCollaborationSession);

module.exports = router;
