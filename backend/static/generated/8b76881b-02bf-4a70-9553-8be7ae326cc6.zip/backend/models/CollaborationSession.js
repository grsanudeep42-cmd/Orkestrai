const mongoose = require('mongoose');

const collaborationSessionSchema = new mongoose.Schema({
  snippetId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Snippet',
    required: true,
  },
  users: [
    {
      userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
      },
      username: {
        type: String,
        required: true,
      },
    },
  ],
  code: {
    type: String,
    default: '',
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('CollaborationSession', collaborationSessionSchema);
