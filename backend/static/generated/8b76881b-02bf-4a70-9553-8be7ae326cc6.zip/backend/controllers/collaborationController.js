const Snippet = require('../models/Snippet');
const CollaborationSession = require('../models/CollaborationSession');

exports.getCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    let session = await CollaborationSession.findOne({ snippetId: req.params.snippetId });
    if (!session) {
      session = await CollaborationSession.create({
        snippetId: req.params.snippetId,
        users: [],
      });
    }

    res.json(session);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.joinCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    let session = await CollaborationSession.findOne({ snippetId: req.params.snippetId });
    if (!session) {
      session = await CollaborationSession.create({
        snippetId: req.params.snippetId,
        users: [{ userId: req.user.id, username: req.user.username }],
      });
    } else {
      session.users.push({ userId: req.user.id, username: req.user.username });
      await session.save();
    }

    res.json(session);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateCollaborationSession = async (req, res) => {
  try {
    const session = await CollaborationSession.findOne({ snippetId: req.params.snippetId });
    if (!session) {
      return res.status(404).json({ message: 'Collaboration session not found' });
    }

    // Update the session based on the request body
    session.code = req.body.code;
    session.users = req.body.users;
    await session.save();

    res.json(session);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.leaveCollaborationSession = async (req, res) => {
  try {
    const session = await CollaborationSession.findOne({ snippetId: req.params.snippetId });
    if (!session) {
      return res.status(404).json({ message: 'Collaboration session not found' });
    }

    // Remove the user from the session
    session.users = session.users.filter((user) => user.userId !== req.user.id);
    await session.save();

    res.json(session);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
