const Snippet = require('../models/Snippet');
const User = require('../models/User');
const { searchSnippets } = require('../utils/elasticsearch');

exports.getAllSnippets = async (req, res) => {
  try {
    const snippets = await Snippet.find().populate('userId', 'username');
    res.json(snippets);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getSnippetById = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.id).populate('userId', 'username');
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }
    res.json(snippet);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.createSnippet = async (req, res) => {
  const { title, description, code, tags, language } = req.body;
  const userId = req.user.id;

  try {
    const snippet = new Snippet({
      title,
      description,
      code,
      tags,
      language,
      userId,
    });
    await snippet.save();

    // Update the user's snippets array
    await User.findByIdAndUpdate(userId, { $push: { snippets: snippet._id } });

    res.status(201).json(snippet);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.updateSnippet = async (req, res) => {
  const { title, description, code, tags, language } = req.body;

  try {
    const snippet = await Snippet.findById(req.params.id);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    // Check if the user is the owner of the snippet
    if (snippet.userId.toString() !== req.user.id) {
      return res.status(403).json({ message: 'You are not authorized to update this snippet' });
    }

    snippet.title = title;
    snippet.description = description;
    snippet.code = code;
    snippet.tags = tags;
    snippet.language = language;
    await snippet.save();

    res.json(snippet);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.deleteSnippet = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.id);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    // Check if the user is the owner of the snippet
    if (snippet.userId.toString() !== req.user.id) {
      return res.status(403).json({ message: 'You are not authorized to delete this snippet' });
    }

    await Snippet.findByIdAndDelete(req.params.id);

    // Remove the snippet from the user's snippets array
    await User.findByIdAndUpdate(req.user.id, { $pull: { snippets: snippet._id } });

    res.json({ message: 'Snippet deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.searchSnippets = async (req, res) => {
  const { query, language, tags } = req.query;

  try {
    const results = await searchSnippets(query, language, tags);
    res.json(results);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
