const CollaborationSession = require('../models/CollaborationSession');

module.exports = (io) => {
  io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('join-collaboration', async (snippetId) => {
      try {
        const session = await CollaborationSession.findOne({ snippetId });
        if (!session) {
          return;
        }

        socket.join(snippetId);
        io.to(snippetId).emit('collaboration-session-updated', session);
      } catch (err) {
        console.error('Error joining collaboration session:', err);
      }
    });

    socket.on('update-collaboration', async (snippetId, updates) => {
      try {
        const session = await CollaborationSession.findOne
