# Generated Project

Run backend with `uvicorn main:app --reload`.
Run frontend with `npm run dev`.
