const Project = require('../models/project');
const ProjectCollaborator = require('../models/projectCollaborator');

exports.createProject = async (req, res) => {
  try {
    const project = await Project.create(req.body);
    res.status(201).json(project);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.getAllProjects = async (req, res) => {
  try {
    const projects = await Project.findAll();
    res.json(projects);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getProjectById = async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id);
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
    res.json(project);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateProject = async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id);
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
    await project.update(req.body);
    res.json(project);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.deleteProject = async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id);
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
    await project.destroy();
    res.json({ message: 'Project deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.addCollaborator = async (req, res) => {
  try {
    const { projectId, userId } = req.body;
    const collaborator = await ProjectCollaborator.create({ projectId, userId });
    res.status(201).json(collaborator);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.removeCollaborator = async (req, res) => {
  try {
    const { projectId, userId } = req.body;
    const collaborator = await ProjectCollaborator.findOne({ where: { projectId, userId } });
    if (!collaborator) {
      return res.status(404).json({ message: 'Collaborator not found' });
    }
    await collaborator.destroy();
    res.json({ message: 'Collaborator removed' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
