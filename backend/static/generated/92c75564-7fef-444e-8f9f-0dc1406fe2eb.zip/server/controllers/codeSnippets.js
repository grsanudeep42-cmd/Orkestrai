const CodeSnippet = require('../models/codeSnippet');

exports.createCodeSnippet = async (req, res) => {
  try {
    const codeSnippet = await CodeSnippet.create(req.body);
    res.status(201).json(codeSnippet);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.getAllCodeSnippets = async (req, res) => {
  try {
    const codeSnippets = await CodeSnippet.findAll();
    res.json(codeSnippets);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getCodeSnippetById = async (req, res) => {
  try {
    const codeSnippet = await CodeSnippet.findByPk(req.params.id);
    if (!codeSnippet) {
      return res.status(404).json({ message: 'Code snippet not found' });
    }
    res.json(codeSnippet);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateCodeSnippet = async (req, res) => {
  try {
    const codeSnippet = await CodeSnippet.findByPk(req.params.id);
    if (!codeSnippet) {
      return res.status(404).json({ message: 'Code snippet not found' });
    }
    await codeSnippet.update(req.body);
    res.json(codeSnippet);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.deleteCodeSnippet = async (req, res) => {
  try {
    const codeSnippet = await CodeSnippet.findByPk(req.params.id);
    if (!codeSnippet) {
      return res.status(404).json({ message: 'Code snippet not found' });
    }
    await codeSnippet.destroy();
    res.json({ message: 'Code snippet deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
