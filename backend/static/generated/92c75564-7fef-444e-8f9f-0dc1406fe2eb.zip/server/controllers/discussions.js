const Discussion = require('../models/discussion');

exports.createDiscussion = async (req, res) => {
  try {
    const discussion = await Discussion.create(req.body);
    res.status(201).json(discussion);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.getAllDiscussions = async (req, res) => {
  try {
    const discussions = await Discussion.findAll();
    res.json(discussions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getDiscussionById = async (req, res) => {
  try {
    const discussion = await Discussion.findByPk(req.params.id);
    if (!discussion) {
      return res.status(404).json({ message: 'Discussion not found' });
    }
    res.json(discussion);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateDiscussion = async (req, res) => {
  try {
    const discussion = await Discussion.findByPk(req.params.id);
    if (!discussion) {
      return res.status(404).json({ message: 'Discussion not found' });
    }
    await discussion.update(req.body);
    res.json(discussion);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.deleteDiscussion = async (req, res) => {
  try {
    const discussion = await Discussion.findByPk(req.params.id);
    if (!discussion) {
      return res.status(404).json({ message: 'Discussion not found' });
    }
    await discussion.destroy();
    res.json({ message: 'Discussion deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
