const { DataTypes } = require('sequelize');
const sequelize = require('../utils/db');
const User = require('./user');

const CodeSnippet = sequelize.define('CodeSnippet', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  code: {
    type: DataTypes.TEXT,
    allowNull: false
  },
