const Snippet = require('../models/Snippet');
const User = require('../models/User');
const elasticsearch = require('../utils/elasticsearch');

exports.getAllSnippets = async (req, res) => {
  try {
    const snippets = await Snippet.find().populate('userId');
    res.json(snippets);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getSnippetById = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.id).populate('userId');
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }
    res.json(snippet);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.createSnippet = async (req, res) => {
  const { title, description, code, tags, language, userId } = req.body;

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const snippet = new Snippet({
      title,
      description,
      code,
      tags,
      language,
      userId,
    });

    await snippet.save();
    user.snippets.push(snippet._id);
    await user.save();

    // Index the new snippet in Elasticsearch
    await elasticsearch.indexSnippet(snippet);

    res.status(201).json(snippet);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.updateSnippet = async (req, res) => {
  const { title, description, code, tags, language } = req.body;

  try {
    const snippet = await Snippet.findById(req.params.id);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    snippet.title = title;
    snippet.description = description;
    snippet.code = code;
    snippet.tags = tags;
    snippet.language = language;

    await snippet.save();

    // Update the snippet in Elasticsearch
    await elasticsearch.updateSnippet(snippet);

    res.json(snippet);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.deleteSnippet = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.id);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    const user = await User.findById(snippet.userId);
    user.snippets.pull(snippet._id);
    await user.save();

    await snippet.remove();

    // Remove the snippet from Elasticsearch
    await elasticsearch.deleteSnippet(snippet._id);

    res.json({ message: 'Snippet deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
