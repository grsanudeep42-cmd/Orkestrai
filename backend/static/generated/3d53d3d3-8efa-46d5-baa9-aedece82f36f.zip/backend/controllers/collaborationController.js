const Snippet = require('../models/Snippet');

exports.getCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId).populate('userId');
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    res.json({
      snippet: {
        _id: snippet._id,
        title: snippet.title,
        code: snippet.code,
      },
      user: {
        _id: snippet.userId._id,
        username: snippet.userId.username,
      },
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.joinCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    // Add the user to the collaboration session
    // (this would involve updating the collaboration session model)

    res.json({ message: 'Joined collaboration session' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    // Update the collaboration session with the new code changes
    // (this would involve updating the collaboration session model)

    snippet.code = req.body.code;
    await snippet.save();

    res.json({ message: 'Collaboration session updated' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.leaveCollaborationSession = async (req, res) => {
  try {
    const snippet = await Snippet.findById(req.params.snippetId);
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }

    // Remove the user from the collaboration session
    // (this would involve updating the collaboration session model)

    res.json({ message: 'Left collaboration session' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
