const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const socketIO = require('socket.io');

const snippetRoutes = require('./routes/snippetRoutes');
const collaborationRoutes = require('./routes/collaborationRoutes');
const authRoutes = require('./routes/authRoutes');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// Middleware
app.use(express.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('Connected to MongoDB'))
.catch((err) => console.error('Error connecting to MongoDB:', err));

// Routes
app.use('/api/snippets', snippetRoutes);
app.use('/api/collaboration', collaborationRoutes);
app.use('/api/auth', authRoutes);

// Socket.IO setup
io.on('connection', (socket) => {
  console.log('A user connected');

  socket.on('join-collaboration', (snippetId) => {
    socket.join(snippetId);
    console.log(`User joined collaboration session for snippet ${snippetId}`);
  });

  socket.on('update-code', (snippetId, newCode) => {
    io.to(snippetId).emit('code-updated', newCode);
    console.log(`Code for snippet ${snippetId} updated`);
  });

  socket.on('disconnect', () => {
    console.log('A user disconnected');
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
