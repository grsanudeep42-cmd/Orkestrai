const socketIO = require('socket.io');

let io;

exports.initSocketIO = (server) => {
  io = socketIO(server);

  io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('join-collaboration', (snippetId) => {
      socket.join(snippetId);
      console.log(`User joined collaboration session for snippet ${snippetId}`);
    });

    socket.on('update-code', (snippetId, newCode) => {
      io.to(snippetId).emit('code-updated', newCode);
      console.log(`Code for snippet ${snippetId} updated`);
    });

    socket.on('disconnect', () => {
      console.log('A user disconnected');
    });
  });

  return io;
};

exports.getSocketIO = () => {
  return io;
};
