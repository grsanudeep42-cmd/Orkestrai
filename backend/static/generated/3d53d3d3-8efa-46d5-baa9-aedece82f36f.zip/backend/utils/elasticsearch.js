const { Client } = require('@elastic/elasticsearch');

const client = new Client({
  node: process.env.ELASTICSEARCH_HOST,
});

exports.indexSnippet = async (snippet) => {
  await client.index({
    index: 'code-snippets',
    body: {
      title: snippet.title,
      description: snippet.description,
      code: snippet.code,
      tags: snippet.tags,
      language: snippet.language,
      userId: snippet.userId.toString(),
    },
  });
};

exports.updateSnippet = async (snippet) => {
  await client.update({
    index: 'code-snippets',
    id: snippet._id.toString(),
    body: {
      doc: {
        title: snippet.title,
        description: snippet.description,
        code: snippet.code,
        tags: snippet.tags,
        language: snippet.language,
      },
    },
  });
};

exports.deleteSnippet = async (snippetId) => {
  await client.delete({
    index: 'code-snippets',
    id: snippetId.toString(),
  });
};

exports.searchSnippets = async (query) => {
  const { body } = await client.search({
    index: 'code-snippets',
    body: {
      query: {
        multi_match: {
          query: query,
          fields: ['title', 'description', 'tags', 'code'],
        },
      },
    },
  });

  return body.hits.hits.map((hit) => hit._source);
};
